import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1440,'height':900})
        await pg.goto('file:///home/user/index.html'); await pg.wait_for_timeout(600)
        r=await pg.evaluate("""()=>{
          const sol=document.querySelector('.sol');
          const h3=sol.querySelector('h3'); const bd=sol.querySelector('.badge'); const bl=sol.querySelector('.built');
          return {ta:getComputedStyle(sol).textAlign, taH3:getComputedStyle(h3).textAlign,
                  aiFlex:getComputedStyle(sol).alignItems,
                  badgeAlign:getComputedStyle(bd).alignSelf, builtAlign:getComputedStyle(bl).alignSelf,
                  badgeBox:bd.getBoundingClientRect().toJSON(), solBox:sol.getBoundingClientRect().toJSON()};
        }""")
        print(r)
        await b.close()
asyncio.run(main())
