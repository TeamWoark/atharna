import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width':1440,'height':900})
        await pg.goto('file:///home/user/index.html')
        await pg.evaluate("document.getElementById('roadmap').scrollIntoView()")
        await pg.wait_for_timeout(1500)
        r = await pg.evaluate("""() => {
          const q=s=>document.querySelector(s).getBoundingClientRect();
          const g=document.querySelector('.rm-grid'), o=document.querySelector('.rm-out');
          return {grid:[g.getBoundingClientRect().top,g.getBoundingClientRect().height],
                  out:[o.getBoundingClientRect().top,o.getBoundingClientRect().height],
                  outStyle:[getComputedStyle(o).marginTop, getComputedStyle(o).position],
                  rm:[...document.querySelectorAll('.rm')].map(e=>[e.getBoundingClientRect().top,e.getBoundingClientRect().height]),
                  card:[...document.querySelectorAll('.rm-card')].map(e=>[e.getBoundingClientRect().top,e.getBoundingClientRect().height]),
                  grad: getComputedStyle(document.querySelector('.hero h1 .grad')).paddingBottom};
        }""")
        print(r)
        await b.close()
asyncio.run(main())
