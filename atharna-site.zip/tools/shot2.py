import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1440,'height':1000})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/user/index.html'); await pg.wait_for_timeout(900)
        for sel,name in [('.learned','20-learned'),('.how2','21-how2'),('#solutions','05-solutions'),('#roadmap','06-roadmap'),('#gallery','07-gallery'),('#team','09-team')]:
            await pg.evaluate(f"document.querySelector('{sel}').scrollIntoView({{block:'center'}})")
            await pg.wait_for_timeout(750)
            await pg.screenshot(path=f'shots/{name}.png')
        m=await b.new_page(viewport={'width':390,'height':844})
        await m.goto('file:///home/user/index.html'); await m.wait_for_timeout(700)
        await m.evaluate("document.getElementById('team').scrollIntoView()"); await m.wait_for_timeout(600)
        await m.screenshot(path='shots/22-mobile-team.png')
        print('errors', errs)
        await b.close()
asyncio.run(main())
