import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for w,h,sel,name in [(390,844,'#team','30-m-team'),(390,844,'.ev-row','31-m-ev'),(390,844,'#roadmap','32-m-roadmap'),(390,844,'#solutions','33-m-sol'),(390,844,'.learned','34-m-learned'),(768,1024,'#team','35-t-team')]:
            pg=await b.new_page(viewport={'width':w,'height':h})
            await pg.goto('file:///home/user/index.html'); await pg.wait_for_timeout(700)
            for _ in range(4):
                await pg.evaluate(f"document.querySelector('{sel}').scrollIntoView({{block:'center'}})")
                await pg.wait_for_timeout(500)
            await pg.screenshot(path=f'shots/{name}.png')
            await pg.close()
        await b.close()
asyncio.run(main())
