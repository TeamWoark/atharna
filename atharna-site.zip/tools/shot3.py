import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1440,'height':1000})
        await pg.goto('file:///home/user/index.html'); await pg.wait_for_timeout(800)
        for _ in range(3):
            await pg.evaluate("document.querySelector('.ev-wrap').scrollIntoView({block:'center'})")
            await pg.wait_for_timeout(700)
        box = await (await pg.query_selector('.ev-row')).bounding_box()
        print(box)
        await pg.screenshot(path='shots/23-evidence.png')
        await b.close()
asyncio.run(main())
