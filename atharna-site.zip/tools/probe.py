import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width':1440,'height':900})
        await pg.goto('file:///home/user/index.html')
        await pg.wait_for_timeout(800)
        r = await pg.evaluate("""() => {
          const out = [];
          document.querySelectorAll('.logo-tile svg').forEach(s=>{
            const b=s.getBoundingClientRect(); out.push({w:b.width,h:b.height, viewBox:s.getAttribute('viewBox'), css:getComputedStyle(s).width});
          });
          const g=document.querySelector('.rm-grid').getBoundingClientRect();
          const o=document.querySelector('.rm-out').getBoundingClientRect();
          const rm=[...document.querySelectorAll('.rm')].map(e=>e.getBoundingClientRect().height);
          const rc=[...document.querySelectorAll('.rm-card')].map(e=>e.getBoundingClientRect().height);
          return {logos:out, grid:[g.top,g.height], out:[o.top,o.height], rm, rc,
                  h1: document.querySelector('.hero h1').getBoundingClientRect().height};
        }""")
        print(r)
        await b.close()
asyncio.run(main())
